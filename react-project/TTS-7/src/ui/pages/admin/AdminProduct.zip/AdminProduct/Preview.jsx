import React from 'react';
import { Button, Modal, ModalHeader, ModalBody, ModalFooter } from 'reactstrap';
import { Rating } from 'flowbite-react';
import { IndianRupee } from 'lucide-react';

export default function Preview({ isOpen, toggle, product }) {
    return (
        <Modal isOpen={isOpen} toggle={toggle}>
            <ModalHeader toggle={toggle}>{product?.title}</ModalHeader>
            <ModalBody>
                {product && (
                    <div className="em5_txt" style={{ margin: "10px" }}>
                        <div>
                            <div>
                                <img
                                    src={product.images}
                                    alt=""
                                    className="img-fluid"
                                    style={{ height: "100px", width: "100px" }}
                                />
                            </div>
                        </div>

                        <div>
                            <p>{product.description}</p>
                        </div>

                        <div>
                            <div className="rating-p">
                                <div>
                                    <Rating>
                                        {product.rating}
                                    </Rating>
                                </div>
                                <div className="ratenum">
                                    <p>(27)</p>
                                </div>
                                <div className="verify-1">
                                    <p>Verified Purchase</p>
                                </div>
                            </div>
                            <div className="price">
                                <div className='text-gray-800'>
                                    <h3>{product.price}<IndianRupee/> </h3>
                                </div>
                                <div className='text-black'>
                                    <h3>Discount: {product.discountPercentage}% off</h3>
                                </div>
                                <div className="strike-1">
                                    <strike>Rs.1,499.00</strike>
                                </div>
                            </div>
                            <div style={{ fontSize: "18px", marginTop: "15px" }}>
                                <p>{product.mainCategory}</p>
                            </div>
                        </div>
                        <div
                            style={{ fontSize: "19px", marginTop: "15px", fontWeight: "inherit" }}
                        >
                            <p>{product.size}</p>
                        </div>
                    </div>
                )}
            </ModalBody>
            <ModalFooter>
                <Button color="primary" onClick={toggle}>Done</Button>
                <Button color="secondary" onClick={toggle}>Cancel</Button>
            </ModalFooter>
        </Modal>
    );
}
