import { Button, Input, Typography } from "@material-tailwind/react";
import React from "react";
import { useCookies } from "react-cookie";
import { useForm, Controller } from "react-hook-form";
import ReactSelect from "react-select";
import { APIinstance } from "../../../api/axiosConfig";
const mainCategorysArr = [
  {label:"Perfume" ,value:"perfume"},
  {label:"Attar" ,value:"attar"},
  {label:"BodyMist" ,value:"bodyMist"},
  {label:"BodySpray" ,value:"bodySpray"},
  {label:"Combo" ,value:"combo"},
  {label:"Gift" ,value:"gift"},
];
const categories = [
  {label:"Flower" ,value:"flower"},
  {label:"Woodi" ,value:"woodi"},
  {label:"Aqua" ,value:"aqua"},
  {label:"Fresh" ,value:"fresh"},
  {label:"Cold" ,value:"cold"},
  {label:"Light" ,value:"light"},
  {label:"Strong" ,value:"strong"},
];
export default function ProductForm({ showModal, setShowModal,flag, refetch  }) {
  let [cookies] = useCookies(['token'])
  const {
    register,
    handleSubmit,
    setValue,
    formState: { errors },
  } = useForm();

  const submitHandler = async (productdata) => {
    // console.log("🚀 ~ submitHandler ~ productdata:", productdata);
    try {      
      let {data} = await APIinstance.post('/product/create',productdata,{
        header:{
          authorization:'bearer '+ cookies?.token,
        },
      })
      setShowModal(false);
      refetch(!flag)
      console.log("🚀 ~ submitHandler ~ data:", data)
    } catch (error) {
      console.log("🚀 ~ submitHandler ~ error:", error)      
    }
  };

  const multiSelect = (mainCat) => {
    let values = mainCat?.map((e) => e.value);
    setValue("mainCategory", values);
  };
  return (
    <>
      {showModal && (
        <>
          <div className="justify-center items-center flex overflow-x-hidden overflow-y-auto fixed inset-0 z-50 outline-none focus:outline-none">
            <div className="relative w-auto my-6 mx-auto max-w-3xl">
              {/*content*/}
              <div className="border-0 rounded-lg shadow-lg relative flex flex-col w-full bg-white outline-none focus:outline-none">
                {/*header*/}
                <div className="flex items-start justify-center p-5 border-b border-solid border-blueGray-200 rounded-t">
                  <h3 className="text-3xl font-semibold">Add Product</h3>
                  {/* <button
                    className="p-1 ml-auto bg-transparent border-0 text-black opacity-5 float-right text-3xl leading-none font-semibold outline-none focus:outline-none"
                    onClick={() => setShowModal(false)}
                  >
                    <span className="bg-transparent text-black opacity-5 h-6 w-6 text-2xl block outline-none focus:outline-none">
                      ×
                    </span>
                  </button> */}
                </div>
                {/*body*/}
                <div className="relative p-6 flex-auto">
                  <form onSubmit={handleSubmit(submitHandler)}>
                    <div className="flex gap-[10px] ">
                      <div className="mb-2 w-[49%]">
                        <label
                          htmlFor=""
                          className="block text-gray-700 font-bold text-md mb-2"
                        >
                          Title
                        </label>
                        <input
                          type="text"
                          {...register("title ", {
                            required: "This Field Is Required",
                          })}
                          className=" w-full rounded-md "
                        />
                      </div>

                      <div className="mb-2  w-[49%]">
                        <label
                          htmlFor=""
                          className="block text-gray-700 font-bold text-md mb-2"
                        >
                          Description
                        </label>
                        <input
                          type="text"
                          {...register("description", {
                            required: "This Field Is Required",
                          })}
                          className=" w-full rounded-md "
                        />
                      </div>
                    </div>

                    <div className="flex gap-[10px]">
                      <div className="mb-2 w-[49%]">
                        <label
                          htmlFor=""
                          className="block text-gray-700 font-bold text-md mb-2"
                        >
                          Price
                        </label>
                        <input
                          type="number"
                          {...register("price", {
                            required: "This Field Is Required",
                          })}
                          className=" w-full rounded-md "
                        />
                      </div>

                      <div className="mb-2 w-[49%]">
                        <label
                          htmlFor=""
                          className="block text-gray-700 font-bold text-md mb-2"
                        >
                          Discount Prize
                        </label>
                        <input
                          type="number"
                          {...register("discountPercentage", {
                            required: "This Field Is Required",
                          })}
                          className=" w-full rounded-md "
                        />
                      </div>
                    </div>

                    <div className="flex gap-[10px]">
                      <div className="mb-2 w-[49%]">
                        <label
                          htmlFor=""
                          className="block text-gray-700 font-bold text-md mb-2"
                        >
                          Available Stock
                        </label>
                        <input
                          type="number"
                          {...register("availableStock", {
                            required: "This Field Is Required",
                          })}
                          className=" w-full rounded-md "
                        />
                      </div>

                      <div className="mb-2 w-[49%]">
                        <label
                          htmlFor=""
                          className="block text-gray-700 font-bold text-md mb-2"
                        >
                          Brand
                        </label>
                        <input
                          type="text"
                          {...register("brand", {
                            required: "This Field Is Required",
                          })}
                          className=" w-full rounded-md "
                        />
                      </div>
                    </div>

                    <div className="flex gap-[10px]">
                      <div className="mb-2 w-[49%]">
                        <label
                          htmlFor=""
                          className="block text-gray-700 font-bold text-md mb-2"
                        >
                          Catagory
                        </label>
                        <ReactSelect
                          {...register("catagory", {
                            required: "This Field Is Required",
                          })}
                          options={categories}
                          onChange={(e) => setValue("catagory", e.value)}
                        />
                      </div>

                      <div className="mb-2 w-[49%]">
                        <label
                          htmlFor=""
                          className="block text-gray-700 font-bold text-md mb-2"
                        >
                          Main Catagory
                        </label>
                        <ReactSelect
                          isMulti
                          {...register("mainCategory", {
                            required: "This Field Is Required",
                          })}
                          options={mainCategorysArr}
                          onChange={multiSelect}
                        />
                      </div>
                    </div>
                    <div className="flex gap-[10px]">
                      <div className="mb-2 w-[49%]">
                        <label
                          htmlFor=""
                          className="block text-gray-700 font-bold text-md mb-2"
                        >
                          Gender
                        </label>
                        <div className="">
                          {["male", "female", "Kids"].map((e, i) => {
                            return (
                              <div className=" flex items-center gap-1" key={i}>
                                
                                <input
                                  type="radio"
                                  {...register("gender", {
                                    required: "This Field Is Required",
                                  })}
                                  value={e}
                                  id={`gender${e}`}
                                />
                                <label htmlFor={`gender${e}`}>{e}</label>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                      <div className="mb-2 w-[49%]">
                        <label
                          htmlFor=""
                          className="block text-gray-700 font-bold text-md mb-2"
                        >
                          Size
                        </label>
                        <div className="">
                          {["50ml", "100ml", "100ml"].map((e, i) => {
                            return (
                              <div className=" flex items-center gap-1" key={i}>
                                <input
                                  type="checkbox"
                                  {...register("size", {
                                    required: "This Field Is Required",
                                  })}
                                  value={e}
                                  id={`size${e}`}
                                />
                                    <label htmlFor={`size${e}`}>{e}</label>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    </div>

                    <div className="mb-2">
                      <label
                        htmlFor=""
                        className="block text-gray-700 font-bold text-md mb-2"
                      >
                        Thumbnail
                      </label>
                      <input
                        type="text"
                        {...register("thumbnail", {
                          required: "This Field Is Required",
                        })}
                        className=" w-full rounded-md "
                      />
                    </div>
                    <div className="flex justify-center mb-2">
                      <button
                        type="button"
                        className="w-[50%] bg-blue-500 p-2 border rounded-md text-xl text-white font-bold "
                        onClick={()=>setShowModal(false)}
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        className="w-[50%] bg-blue-500 p-2  border rounded-md text-xl text-white font-bold "
                      >
                        {" "}
                        Submit
                      </button>
                    </div>
                  </form>
                </div>
                {/*footer*/}
                {/* <div className="flex items-center justify-end p-6 border-t border-solid border-blueGray-200 rounded-b">
                  <button
                    className="text-red-500 background-transparent font-bold uppercase px-6 py-2 text-sm outline-none focus:outline-none mr-1 mb-1 ease-linear transition-all duration-150"
                    type="button"
                    onClick={() => setShowModal(false)}
                  >
                    Close
                  </button>
                  <button
                    className="bg-emerald-500 text-white active:bg-emerald-600 font-bold uppercase text-sm px-6 py-3 rounded shadow hover:shadow-lg outline-none focus:outline-none mr-1 mb-1 ease-linear transition-all duration-150"
                    type="button"
                    onClick={() => setShowModal(false)}
                  >
                    Save Changes
                  </button> 
                </div>*/}
              </div>
            </div>
          </div>
          <div className="opacity-25 fixed inset-0 z-40 bg-black"></div>
        </>
      )}
    </>
  );
}
