import React, { useState } from "react";
import ProductTable from "./ProductTable";
import { Button } from "@material-tailwind/react";
import ProductForm from "./ProductForm";
export default function Product() {
  const [showModal, setShowModal] = useState(false);
  let [flag, setFlag] = useState(true);

  const refetch = () => setFlag(!flag);
  return (
    <>
      <div className="px-5">
        <Button onClick={() => setShowModal(true)}>Add product</Button>
        <ProductForm showModal={showModal}  refetch={refetch} flag={flag}  setShowModal={setShowModal}/>
      </div>
       <ProductTable refetch={refetch} flag={flag} />
    </>
  );
}
