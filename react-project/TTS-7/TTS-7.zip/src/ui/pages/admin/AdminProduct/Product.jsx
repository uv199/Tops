import React from "react";
import ProductTable from "./ProductTable";

export default function Product() {
  return (
    <>
      <ProductTable />
    </>
  );
}

