import React from "react";

export default function ProductTable() {
  return (
   <div>Table</div>
  );
}
//  /product/getAll
