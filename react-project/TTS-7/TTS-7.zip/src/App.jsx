import "./App.css";
import Router from "./router/router";

export default function App() {
  return <Router />;
}
