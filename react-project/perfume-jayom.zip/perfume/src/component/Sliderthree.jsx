import React from 'react'
import 'react-multi-carousel/lib/styles.css'; // Import default carousel styles
import Cardcom from './Cardcom';
import datathree from './datathree.json'
import Carousel from 'react-multi-carousel';


const responsive = {
    superLargeDesktop: {
        breakpoint: { max: 4000, min: 3000 },
        items: 7 // Adjusted items to display 7 items
    },
    desktop: {
        breakpoint: { max: 3000, min: 1024 },
        items: 4
    },
    tablet: {
        breakpoint: { max: 1024, min: 464 },
        items: 2
    },
    mobile: {
        breakpoint: { max: 464, min: 0 },
        items: 1
    }
};

export default function Sliderthree() {
    return (
        <>
            <div class='py-10 flex justify-between items-center '>
                <i class='text-5xl title font-italic'>Trending Products </i>
                <a href="#" class="flex items-center inherit-color text-black hover:text-blue-500">Discover all <img class="ms-1" width="18px" src="/public/arrow-right.svg" alt="" /> </a>
            </div>
            <div className="w-[1320px] mx-auto mt-5 pt-5">
                <Carousel
                    responsive={responsive}
                    showDots={false} // Hide dots navigation
                    arrows={true} // Show arrows navigation
                    infinite={false} // Enable infinite loop
                >
                    {datathree.map(products => (
                        <Cardcom key={products.id} item={products} />
                    ))}
                </Carousel>
            </div>

            <div class='py-10 flex justify-between items-center '>
                <i class='text-5xl title font-italic'>Instagram </i>
                <a href="https://www.instagram.com/ajmalperfumesin/" class="flex items-center inherit-color text-black hover:text-blue-500">@ajmalperfumes <img class="ms-1" width="18px" src="/public/arrow-right.svg" alt="" /> </a>
            </div>
        </>
    )
}





