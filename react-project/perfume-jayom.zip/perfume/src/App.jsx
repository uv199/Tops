import { useState } from 'react'
import './App.css'
import SliderCom from './component/Slider';
import "react-multi-carousel/lib/styles.css";
import Cardcom from './component/Cardcom';
import Arrivals from './component/Arrivals';
import Bestseller from './component/Bestseller';
import Slidertwo from './component/Slidertwo';
import PopularCat from './component/PopularCat';
import Sliderthree from './component/Sliderthree'; 


function App() {

  return (
    <div >
      {/* <Cardcom /> */}
      <Arrivals />
      <SliderCom />
      <Bestseller />
      <Slidertwo />
      <PopularCat />
      <Sliderthree />


    </div >
  )
}

export default App
