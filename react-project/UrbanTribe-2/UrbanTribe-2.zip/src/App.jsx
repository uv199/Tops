import "./App.css";
import Router from "./router/Router";
import { CookiesProvider } from "react-cookie";
function App() {
  return (
    <CookiesProvider defaultSetOptions={{ path: "/" }}>
      <Router />;
    </CookiesProvider>
  );
}

export default App;
