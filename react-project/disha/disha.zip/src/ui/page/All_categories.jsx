import React from 'react'

export default function All_categories() {
  return (
    <div>All_categories</div>
  )
}
