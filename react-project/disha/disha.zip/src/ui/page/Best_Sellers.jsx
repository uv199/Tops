import React from 'react'


export default function Best_Sellers () {
  return (
    <div>

     
      <h1>Best_sellers</h1>
      
    </div>
  )
}
