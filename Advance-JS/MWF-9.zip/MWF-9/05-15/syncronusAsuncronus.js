console.log("----1-----");
console.log("----2-----");
console.log("----3-----");
setTimeout(() => {
  console.log("----4-----");
}, 1000);
console.log("----5-----");
console.log("----6-----");
