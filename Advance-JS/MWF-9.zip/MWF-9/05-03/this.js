// let obj = {
//   name: "urvish",
//   age: 23,
//   print: function () {
//     console.log("my name is ", this.name);
//   },
//   print2: () => {
//     console.log("my name is ", this.name);
//   },
// };

// obj.print();
// obj.print2();
