var a

console.log("-----------  a----------->", a)
var a = 80

console.log("-----------  b----------->", b)
let b = 90
