for (let i = 0; i < 10; i++) {
    console.log("hello world")
}

/*

nvm -> node version manager -> we can manage multiple version of node by using nvm

1. install node directly
2. install node by using nvm
    - nvm -v --> to check version of nvm
    - nvm list --> to show a list of installed node version
    - nvm install (node_version) --> to install node version
    - nvm uninstall (node_version) --> to uninstall node version
    - nvm use (node_version) --> to chnage node version
3. node 
   - node -v --> to check node version
   - node fileName.js --> to run file 

4. cd.. --> move to back folder 
5. cd ./foldername --> move into folder 
6. cls --> clear terminal 

press tab for suggesion
up and down arrow for recently hited command
clt + ` --> to open/close terminal

*/
