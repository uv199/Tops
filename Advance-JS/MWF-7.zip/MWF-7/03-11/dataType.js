/*

let str1 = "urvish's";
let str2 = 'manoj said "hello world"...!';
let str3 = `' "



'`;
${expression} => template litrals

let age = 23;
let name = "Urvish";
let str4 = `my name is ${name} and i'm ${age} years old. after 5 year my age will be 
${age + 5}`;

console.log("-----------  str4----------->", str4);

let nameArr = ["urvish", "manoj", "meet"];

for (let i = 0; i < nameArr.length; i++) {
  const element = nameArr[i];
  console.log(`my name is ${element}`);
}

*/

