let x = "red";

// if (x === "red") {
//   console.log("x is red");
// }
// if (x === "yellow") {
//   console.log("x is yellow");
// }
// if (x === "red") {
//   console.log("x is green");
// }
// if (x === "blue") {
//   console.log("x is blue");
// }

if (x === "red") {
  console.log("x is red");
} else if (x === "yellow") {
  console.log("x is yellow");
} else if (x === "red") {
  console.log("x is green");
} else if (x === "blue") {
  console.log("x is blue");
}
/*
less then 36 you are failed 
less then 50 gratter then 36 below average 
less then 70 gratter then 50 average 
less then 90 gratter then 70 above average 
above 90 exelent  
above 100 mark is not valid  

[1,2,3,4,5,26,7,8,9,0,3,4] => biggest / smallest no
[1,2,3,4,5] => odd/ even no\
odd => [1,3,5]
even => [2,4]
*/
