let familyData = {
  name: "Hiralal Patel",
  age: 80,
  children: [
    {
      name,
      age,
      aqupation,
      vehicle: [{ name, number }],
      child: [
        {
          name,
          age,
        },
      ],
    },
    {
      name,
      age,
      aqupation,
      vehicle: [{ name, number }],
      child: [
        {
          name,
          age,
        },
      ],
    },
    {
      name,
      age,
      aqupation,
      vehicle: [{ name, number }],
      child: [
        {
          name,
          age,
        },
      ],
    },
  ],
};
