const importItem = require("./fun1");
console.log("-----------  importItem----------->", importItem);

// importItem()

const data = require("./data.json");
console.log("-----------  data----------->", data);
