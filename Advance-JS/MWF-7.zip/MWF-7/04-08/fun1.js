// function print(params) {
//   console.log("------hello world----->");
// }

// module.exports = print;


console.log("=-=--=-=-==--=-=-=>")
