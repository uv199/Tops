// parseFloat()	It converts the given string into a floating point number.

// console.log("parFloat()", Number.parseFloat("12.23"));
// console.log("parFloat()", Number.parseFloat("12.0"));
// console.log("parFloat()", Number.parseFloat("12test"));
// console.log("parFloat()", Number.parseFloat("test12"));

// parseInt()	It converts the given string into an integer number.

// console.log("parseInt()", Number.parseInt("12.23"));
// console.log("parseInt()", Number.parseInt("12"));
// console.log("parseInt()", Number.parseInt("12test"));
// console.log("parseInt()", Number.parseInt("test12"));

// toFixed()	It returns the string that represents a number with exact digits after a decimal point.

// let x = 12.223423423;
// let x = 12.223553423;
let x = 12;
console.log("tofilxed()", x.toFixed(3));
