let user = {
  name: "urvish",
  //   age: 23,
  //   address: {
  //     city: "surat",
  //     pinCode: 395007,
  //   },
  //   print: function (params) {
  //     console.log("-----------  print----------->");
  //   },
};

obj.state = "gujarat";
// console.log("city", user?.address?.city);
// console.log("age", user?.age);

// user?.print?.();

let data = null;

data?.map?.((e) => {
  console.log("---e---", e);
});
