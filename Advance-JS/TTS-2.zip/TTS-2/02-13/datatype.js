let str1 = "urvish's";
let str2 = 'urvish"';
let str3 = `urvish'"`;
let number = 8160579279;
// let msg = "my number is " + number + ".";
// let msg = `my number is ${5+5}.`;
let msg = `my number is ${number}.`;
console.log("-----------  msg----------->", msg);

let arr = ["urvish", "disha", "zubair", "vinita"];

for (let i = 0; i < arr.length; i++) {
  console.log(`my name is ${arr[i]}. `);
}

// number
let n1 = 122;
let n2 = -0.122;
let n3 = 0.122;

// boolean

// true/false
let yes = true;
console.log("-----------  yes----------->", typeof yes);
console.log("-----------  yes----------->", typeof "strbjb");
console.log("-----------  yes----------->", typeof 454);
console.log("-----------  yes----------->", typeof null);
console.log("-----------  yes----------->", typeof [1, 2, 3]);
console.log("-----------  yes----------->", typeof {});
console.log("-----------  yes----------->", typeof function test(params) {});

// single property multy value
let color = ["red", "yellow", "blue"];

let userDetails = [
  {
    name: "uv",
    age: 23,
    panCard: "FMGPP3019F",
  },
  {
    name: "vinita",
    age: 21,
  },
  {
    name: "zubair",
    age: 18,
  },
];
