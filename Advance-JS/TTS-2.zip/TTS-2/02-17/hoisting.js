// console.log("-----------  x----------->", x);
// let x = 100;

console.log("-----------  y----------->", y);
var y = 100;

console.log("-----------  z----------->", z);
const z = 200;
