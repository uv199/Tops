let arr = [1, 2, 3, 4, 5];
console.log("-----------  arr----------->", arr);

/*
// push(...items) – adds items to the end,
arr.push(10);
// arr.push(10, 11, 12);

console.log("-----------  arr----------->", arr);
// pop() – remove an item from the end,
arr.pop();
console.log("-----------  arr----------->", arr);

// unshift(...items) – adds items to the beginning.
// arr.unshift(10);
arr.unshift(10, 11, 12);
console.log("-----------  arr----------->", arr);

// shift() – remove an item from the beginning,
arr.shift();
// arr.shift();
console.log("-----------  arr----------->", arr);

// slice(start, end) – creates a new array, copies elements from index start till end (not inclusive) into it.
// let spliceArr = arr.slice(1, 3);
let spliceArr = arr.slice(1, -5);
console.log("-----------  spliceArr----------->", spliceArr);

// splice(startIndex, deleteCount, ...items) – at index pos deletes deleteCount elements and inserts items.
// arr.splice(1, 0, 10,20,30); // only add
// arr.splice(1, 2, 20,30); // add and remove
arr.splice(1, 2); // only remove
console.log("-----------  arr----------->", arr);

*/
